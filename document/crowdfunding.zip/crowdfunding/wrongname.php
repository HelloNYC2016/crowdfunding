<?php
echo 'This username has been occupied, please <a href="username.php">try again.</a>';
?>