<nav class="navbar navbar-default "  role="navigation">
  <div class="container-fluid">
    <!-- Brand -->
    <div class="navbar-header">
      <a class="navbar-brand" href="index.php">Fundraiser</a>
    </div>
    <!-- Search -->
    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
      <form class="navbar-form navbar-left" role="search" action="result.php" method="POST">
        <div class="form-group">
          <div class="input-group">
            <span class="input-group-addon"><i class="fa fa-search"></i></span>
                        <input type="text" class="form-control" name="keyword" id="send_keyword" placeholder="Search for something">
          </div>
        </div>
      </form>
      <ul class="nav navbar-nav navbar-right">
        <li><a href="login.html">Build fundraiser</a></li>
        <li><a href="login.html">Log In</a></li>
        <li><a href="signup.php">Sign Up</a></li>
      </ul>
    </div>
    <!-- /.navbar-collapse -->
  </div>